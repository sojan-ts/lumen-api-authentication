# tymon/jwt-auth based authentication sample
This sample project illustrate how we can implement token based authentication